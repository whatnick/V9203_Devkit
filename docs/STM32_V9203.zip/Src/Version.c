#include  "includes.h"


#define HVER0  (__VER_HARD_B__)


const __root uint8  gCuc_VerSoft[]= __VER_SOFT_B__;
const __root uint8  gCuc_VerHard[] = {HVER0};
